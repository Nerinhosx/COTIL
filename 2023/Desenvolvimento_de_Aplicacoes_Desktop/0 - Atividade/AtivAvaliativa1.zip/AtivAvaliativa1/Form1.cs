﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtivAvaliativa1
{
    public partial class Form1 : Form
    {
        double s, st=0;
        int i = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((String.IsNullOrEmpty(textBox1.Text)) || (String.IsNullOrEmpty(textBox2.Text)) || (String.IsNullOrEmpty(textBox3.Text)))
            {
                MessageBox.Show("Campos obrigatórios estão vazios.", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                s = double.Parse(textBox2.Text) * double.Parse(textBox3.Text);
                listBox1.Items.Add(textBox1.Text + " - " + s);
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                st += s;
            }
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            label5.Text = "0";
            s = 0;
            st = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Text = st.ToString();
            MessageBox.Show("Compra efetuada com sucesso!", "Sistema informa:", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}