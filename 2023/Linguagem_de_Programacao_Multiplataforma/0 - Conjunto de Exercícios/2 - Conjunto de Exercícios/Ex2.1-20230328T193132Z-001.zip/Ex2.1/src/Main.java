public class Main {
    public static void main(String[] args) {
        System.out.println(ConversaoDeTemperatura.paraF(0));
        System.out.println(ConversaoDeTemperatura.paraF(100));
        System.out.println(ConversaoDeTemperatura.paraC(50));
    }
}