public class Main {
    public static void main(String[] args) {
        MaiorEMenor m = new MaiorEMenor();
        System.out.println(m.MaiorDe2(1, 2));
        System.out.println(m.MaiorDe3(2,1,8));
        System.out.println(m.MaiorDe4(4, 6,8,3));
        System.out.println(m.MaiorDe5(4,8,2,0,19));
    }
}