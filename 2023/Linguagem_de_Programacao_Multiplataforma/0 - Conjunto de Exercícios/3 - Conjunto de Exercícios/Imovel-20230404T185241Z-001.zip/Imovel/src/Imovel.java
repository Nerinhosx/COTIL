public class Imovel{
    protected int code;
    protected String edc;
    protected double prc;

    public Imovel(int code, String edc, double prc)
    {
        this.code=code;
        this.edc=edc;
        this.prc=prc;
    }
}
