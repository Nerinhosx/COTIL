public class Main {
    public static void main(String[] args) {
        Medico m1 = new Medico(true);
        ClinicoGeral cg1 = new ClinicoGeral(false, true);
        Cirurgiao c1 = new Cirurgiao(true);
    }
}