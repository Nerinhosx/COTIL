public class Medico {
    private boolean trabH;

    public Medico(boolean trabH)
    {
        this.trabH=trabH;
    }

    public void tratarPaciente()
    {
        System.out.println("Doutor está tratando o paciente.");
    }
}
