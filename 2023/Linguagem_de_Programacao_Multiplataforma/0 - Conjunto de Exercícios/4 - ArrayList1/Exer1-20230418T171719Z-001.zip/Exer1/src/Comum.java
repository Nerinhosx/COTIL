public class Comum extends Ingresso{

    public Comum(double valor) {
        super(valor);
    }
}
