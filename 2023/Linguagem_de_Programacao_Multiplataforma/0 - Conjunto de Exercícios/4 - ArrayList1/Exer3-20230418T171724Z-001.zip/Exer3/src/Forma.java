public class Forma {

    public Forma() {
    }

    public double obterArea()
    {
        return 0;
    }
}
