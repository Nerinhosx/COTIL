public class FormaBidimensional extends Forma{
    public FormaBidimensional() {
    }
}
