public class FormaTridimensional extends Forma{

    public FormaTridimensional() {
    }

    public double obterVolume()
    {
        return 0;
    }
}
