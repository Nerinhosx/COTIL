public class Funcionario {
    private String nome;

    public Funcionario(String nome)
    {
        this.nome=nome;
    }

    public double getPay()
    {
        return 0;
    }

    public void setPay()
    {
    }
}
