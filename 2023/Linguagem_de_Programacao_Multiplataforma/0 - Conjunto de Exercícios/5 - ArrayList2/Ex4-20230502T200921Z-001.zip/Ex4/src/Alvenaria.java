public class Alvenaria extends Produtos{

    public Alvenaria(int cod, String desc, double prc, String uni)
    {
        super(cod, desc, prc, uni);
    }
}
