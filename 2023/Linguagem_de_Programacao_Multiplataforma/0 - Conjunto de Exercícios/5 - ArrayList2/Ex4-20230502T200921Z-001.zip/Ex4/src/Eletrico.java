public class Eletrico extends Produtos{

    public Eletrico(int cod, String desc, double prc, String uni)
    {
        super(cod, desc, prc, uni);
    }
}
