public class Hidraulico extends Produtos{

    public Hidraulico(int cod, String desc, double prc, String uni)
    {
        super(cod, desc, prc, uni);
    }
}
