public class Loja {
}
