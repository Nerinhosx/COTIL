public interface CarbonFootprint {
    public double getCarbonFootprint();
}
