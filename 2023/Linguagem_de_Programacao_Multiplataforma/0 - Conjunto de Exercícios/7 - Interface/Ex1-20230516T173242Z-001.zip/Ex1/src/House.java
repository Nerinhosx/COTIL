public class House extends Building{

    public House(int nPes, boolean usoER, int nLamp, boolean usoAC) {
        super(nPes, usoER, nLamp, usoAC);
    }
}
