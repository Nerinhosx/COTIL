public class School extends Building{

    public School(int nPes, boolean usoER, int nLamp, boolean usoAC) {
        super(nPes, usoER, nLamp, usoAC);
    }
}
