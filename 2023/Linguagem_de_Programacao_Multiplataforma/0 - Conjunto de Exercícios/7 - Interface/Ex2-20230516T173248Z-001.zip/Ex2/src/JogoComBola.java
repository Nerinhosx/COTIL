public abstract class JogoComBola implements Jogo{
    public void setNomeEquipes(String eqp1, String eqp2)
    {}
}
