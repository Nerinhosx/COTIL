public abstract class JogoDeCartas implements Jogo{
    public int qtdCartasDistribuidas()
    {
        return 0;
    }

    public int numeroParticipantes()
    {
        return 0;
    }

}
