public interface AreaCalculavel {
    public abstract double calcularArea();
}