public class Main {
    public static void main(String[] args) {
        Ponto2D p2d = new Ponto2D(2.5, 8.9);
        Ponto3D p3d = new Ponto3D(4.8, 1.85, 4.78);

        System.out.println(p2d.toString());
        System.out.println("\n" + p3d.toString());
    }
}