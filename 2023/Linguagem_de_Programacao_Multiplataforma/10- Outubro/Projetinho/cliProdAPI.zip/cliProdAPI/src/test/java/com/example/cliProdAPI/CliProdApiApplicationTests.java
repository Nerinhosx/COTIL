package com.example.cliProdAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CliProdApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
