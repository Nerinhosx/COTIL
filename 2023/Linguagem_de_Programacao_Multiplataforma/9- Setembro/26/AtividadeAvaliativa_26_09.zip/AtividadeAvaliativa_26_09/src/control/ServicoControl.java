/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.sql.SQLException;
import java.util.ArrayList;
import model.DAO.ServicoDAO;
import model.Servico;

/**
 *
 * @author aluno
 */
public class ServicoControl {
    
    public void cadastrar(int cod, String desc, double prc) throws SQLException, ClassNotFoundException
    {
        Servico svc = new Servico(cod, desc, prc);
        ServicoDAO svcDAO = new ServicoDAO();
        svcDAO.cadastrarServico(svc);
    }
    
    public void excluir(int cod) throws SQLException, ClassNotFoundException
    {
        ServicoDAO svcDAO = new ServicoDAO();
        svcDAO.excluirServico(cod);
    }
    
    public ArrayList<Servico> buscar() throws SQLException, ClassNotFoundException
    {
        ServicoDAO svcDAO = new ServicoDAO();
        return svcDAO.buscarServico();
    }
}
