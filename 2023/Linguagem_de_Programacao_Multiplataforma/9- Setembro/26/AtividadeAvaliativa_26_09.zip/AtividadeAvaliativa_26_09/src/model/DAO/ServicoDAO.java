/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.DAO;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Servico;

/**
 *
 * @author aluno
 */
public class ServicoDAO {
    Connection con = null;
    
    public void cadastrarServico(Servico svc) throws SQLException, ClassNotFoundException
    {
        con = new Conexao().getConnection();
        String sql = "Insert into servicoJava (codigo,descricao,preco) values (?,?,?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1, svc.getCod());
        stmt.setString(2, svc.getDesc());
        stmt.setDouble(3, svc.getPrc());
        stmt.execute();
        stmt.close();
    }
    
    public void excluirServico(int cod) throws SQLException, ClassNotFoundException
    {
        con = new Conexao().getConnection();
        String sql = ("Delete from servicoJava where codigo = "+ cod);
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.execute();
        stmt.close();
    }
    
    public ArrayList<Servico> buscarServico() throws SQLException, ClassNotFoundException
    {
        ResultSet rs;
        ArrayList<Servico> lista = new ArrayList();
        con = new Conexao().getConnection();
        String sql = "Select * from servicoJava";
        PreparedStatement stmt = con.prepareStatement(sql);
        rs = stmt.executeQuery();
        while(rs.next())
        {
            int cod = rs.getInt("codigo");
            String desc = rs.getString("descricao");
            double prc = rs.getDouble("preco");
            Servico svc = new Servico(cod, desc, prc);
            lista.add(svc);
        }
        stmt.close();
        con.close();
        return lista;
    }
}
