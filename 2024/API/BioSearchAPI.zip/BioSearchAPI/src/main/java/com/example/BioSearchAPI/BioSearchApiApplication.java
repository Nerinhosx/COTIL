package com.example.BioSearchAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BioSearchApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BioSearchApiApplication.class, args);
	}

}
