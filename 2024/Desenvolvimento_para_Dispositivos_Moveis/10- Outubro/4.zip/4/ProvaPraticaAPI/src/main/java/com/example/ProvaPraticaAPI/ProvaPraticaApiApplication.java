package com.example.ProvaPraticaAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProvaPraticaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvaPraticaApiApplication.class, args);
	}

}
