package com.example.ProvaPraticaAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvaPraticaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
