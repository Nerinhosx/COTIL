package com.example.flutter_application_prova_pratica_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
